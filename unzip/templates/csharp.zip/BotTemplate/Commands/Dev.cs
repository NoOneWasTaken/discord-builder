﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using NLog;

namespace BotTemplate.Commands;

[SlashCommandGroup("dev", "Development commands.")]
public class Dev : ApplicationCommandModule
{
    public static ulong? CommandsGuild { get; set; } = 0; // Set to a GuildId to make this command group guild only
    private Logger _logger; // Once again NLog, in case

    public Dev(Logger logger)
    {
        _logger = logger; //NLog added through Dep Injection
    }

    [SlashCommand("ping", "Says pong.")]
    public async Task Log(InteractionContext ctx)
    {
        await ctx.CreateResponseAsync(new DiscordInteractionResponseBuilder().WithContent("Pong!"));
    }

    [SlashCommand("clearcommands", "Clears all the bot's commands and restarts the bot.")]
    public async Task ClearCommands(InteractionContext ctx, [Option("GuildId", "The guild to clear the commands of.")] string GuildIdStr = "")
    {
        await ctx.DeferAsync(false);

        if (GuildIdStr == "")
        {
            Console.WriteLine("Removing old commands");
            foreach (DiscordApplicationCommand Command in ctx.Client.GetGlobalApplicationCommandsAsync().Result)
            {
                await ctx.Client.DeleteGlobalApplicationCommandAsync(Command.Id);
            }
        }
        else if (GuildIdStr != "")
        {
            ulong GuildId;
            bool Converted = ulong.TryParse(GuildIdStr, out GuildId);

            if (!Converted)
            {
                await ctx.EditResponseAsync(new DiscordWebhookBuilder().WithContent($"Failed to convert {GuildIdStr} to ulong."));
                return;
            }

            Console.WriteLine($"Removing old commands from guild with ID {GuildId}");
            foreach (DiscordApplicationCommand Command in ctx.Client.GetGuildApplicationCommandsAsync(GuildId).Result)
            {
                await ctx.Client.DeleteGuildApplicationCommandAsync(GuildId, Command.Id);
            }
        }

        System.Diagnostics.Process.Start(Environment.ProcessPath!);

        await ctx.EditResponseAsync(new DiscordWebhookBuilder().WithContent($"The bot is being restarted!"));
        Console.WriteLine($"<@{ctx.User.Id}>({ctx.User.Id}) used `/{ctx.QualifiedName}` {(GuildIdStr == "" ? "" : $"with ID `{GuildIdStr}`")}");

        Environment.Exit(0);
    }

    [SlashCommand("restart", "Restarts the bot.")]
    public async Task Restart(InteractionContext ctx)
    {
        await ctx.DeferAsync(false);

        System.Diagnostics.Process.Start(Environment.ProcessPath!);

        await ctx.EditResponseAsync(new DiscordWebhookBuilder().WithContent($"Restarting!"));
        Console.WriteLine($"<@{ctx.User.Id}>({ctx.User.Id}) used `/{ctx.QualifiedName}`!");

        Environment.Exit(0);
    }

    [SlashCommand("shutdown", "Shuts down the bot.")]
    public async Task ShutDown(InteractionContext ctx)
    {
        await ctx.DeferAsync(false);

        await ctx.EditResponseAsync(new DiscordWebhookBuilder().WithContent($"Shutting down!"));
        Console.WriteLine($"<@{ctx.User.Id}>({ctx.User.Id}) used `/{ctx.QualifiedName}`!");

        Environment.Exit(0);
    }
}