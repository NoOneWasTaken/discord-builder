﻿using BotTemplate.Services;
using DSharpPlus;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NLog.Config;
using NLog.Targets;
using NLog;
using NLog.Extensions.Logging;

namespace BotTemplate;

public static class Program
{
    private static readonly string? _token = Environment.GetEnvironmentVariable("TOKEN");
    public static readonly IServiceProvider _serviceProvider = CreateProvider();
    private static readonly Logger _logger = LogManager.GetCurrentClassLogger(); // NLog in case you'd want to use it

    private static LoggingConfiguration LoggerConfig()
    {
        var _config = _serviceProvider.GetRequiredService<IConfiguration>();

        var LogConsole = new ConsoleTarget("logconsole") { Layout = _config.GetSection("ConsoleLoggerLayout").Value };
        var LogFile = new FileTarget("logfile") { FileName = "${basedir}/logs/${shortdate}.log", Layout = _config.GetSection("FileLoggerLayout").Value };

        var config = new LoggingConfiguration();
        config.AddRule(LogLevel.Debug, LogLevel.Fatal, LogConsole);
        config.AddRule(LogLevel.Trace, LogLevel.Fatal, LogFile);

        return config;
    }

    private static IServiceProvider CreateProvider()
    {
        if (_token == null || _token == string.Empty)
        {
            _logger.Fatal("Could not find \"TOKEN\" environment variable.");
        }

        var BotConfig = new DiscordConfiguration()
        {
            Token = _token,
            TokenType = TokenType.Bot,
            Intents = DiscordIntents.AllUnprivileged | DiscordIntents.MessageContents,
            LogUnknownEvents = false
        };

        return new ServiceCollection()
            .AddSingleton(BotConfig)
            .AddSingleton<DiscordClient>()
            .AddLogging(loggingBuilder =>
            {
                loggingBuilder.AddNLog();
            })
            .BuildServiceProvider();
    }

    public static void Main(string[] args) =>
        Program.MainAsync(args).GetAwaiter().GetResult();

    public static async Task MainAsync(string[] args)
    {
        var _client = _serviceProvider.GetRequiredService<DiscordClient>();
        LogManager.Configuration = LoggerConfig();

        _client.Ready += OnClientConnect;

        await new CommandHandler(_client).InitializeAsync();
        await _client.ConnectAsync();

        await Task.Delay(-1);
    }

    private static Task OnClientConnect(DiscordClient Client, DSharpPlus.EventArgs.ReadyEventArgs Args)
    {
        Console.WriteLine($"Logged in as {Client.CurrentUser.Username}#{Client.CurrentUser.Discriminator}");

        return Task.CompletedTask;
    }
}