﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using Microsoft.Extensions.Configuration;

namespace BotTemplate.Services;

// Command parameter option providers go here
