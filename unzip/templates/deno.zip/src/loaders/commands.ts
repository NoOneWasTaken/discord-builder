import * as path from "node:path";
import * as fs from "node:fs";

import type { Command } from "../commands/index.ts";
import { CommandSchema } from "../commands/index.ts";

export async function loadCommands(baseDir: string) {
  const commands = new Map<string, Command>();
  const commandDir = fs.readdirSync(baseDir);

  for (const commandFile of commandDir) {
    if (!commandFile.endsWith(".ts") || commandFile == "index.ts") continue;

    const commandPath = path.join(baseDir, commandFile);
    const commandModule: Command =
      (await import(`file://${commandPath}`)).default;

    if (CommandSchema.safeParse(commandModule).success) {
      commands.set(commandModule.data.name, commandModule);
    } else {
      console.error(
        `Events failed to pass the integrity check (${commandFile}).`,
      );
    }
  }

  return commands;
}
