import * as path from "node:path";
import * as fs from "node:fs";
import { Event, EventSchema } from "../events/index.ts";

export async function loadEvents(baseDir: string) {
  const eventsDir = fs.readdirSync(baseDir);
  const events = [];

  for (const eventFile of eventsDir) {
    if (!eventFile.endsWith(".ts") || eventFile == "index.ts") continue;

    const eventPath = path.join(baseDir, eventFile);
    const eventModule: Event = (await import(`file://${eventPath}`)).default;

    if (EventSchema.safeParse(eventModule).success) {
      events.push(eventModule);
    } else {
      console.error(
        `Events failed to pass the integrity check (${eventFile}).`,
      );
    }
  }

  return events;
}
