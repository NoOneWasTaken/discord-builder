import * as path from "node:path";
import { API } from "npm:@discordjs/core@^1.2.0/http-only";
import { REST } from "npm:discord.js@^14.16.0";
import { loadCommands } from "./loaders/commands.ts";

const rootDir = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const commands = await loadCommands(path.join(rootDir, "src/commands"));
const commandData = [...commands.values()].map((command) => command.data);

const rest = new REST({ version: "10" }).setToken(Deno.env.get("TOKEN")!);
const api = new API(rest);

const result = await api.applicationCommands.bulkOverwriteGlobalCommands(
  Deno.env.get("APPLICATION_ID")!,
  commandData,
);

console.log(`Successfully registered ${result.length} commands.`);
