import type { CommandInteraction, RESTPostAPIApplicationCommandsJSONBody } from "npm:discord.js@^14.16.0";
import { z } from "npm:zod@^3.23.8";

export type Command = {
  data: RESTPostAPIApplicationCommandsJSONBody;
  execute(interaction: CommandInteraction): Promise<void> | void;
};

export const CommandSchema = z.object({
  data: z.record(z.any()),
  execute: z.function(),
});
