import { Client, GatewayIntentBits } from "npm:discord.js@14.16.0";
import * as path from "node:path";

import { loadEvents } from "./loaders/events.ts";
import { loadCommands } from "./loaders/commands.ts";
import { registerEvents } from "./loaders/registerEvents.ts";

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const rootDir = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");

const events = await loadEvents(path.join(rootDir, "src/events"));
const commands = await loadCommands(path.join(rootDir, "src/commands"));

registerEvents(commands, events, client);

void client.login(Deno.env.get("TOKEN"));
