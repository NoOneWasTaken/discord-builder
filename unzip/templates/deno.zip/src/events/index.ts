import type { ClientEvents } from "npm:discord.js@14.16.0";
import { z } from "npm:zod@^3.23.8";

export type Event<T extends keyof ClientEvents = keyof ClientEvents> = {
  name: T;
  once?: boolean;
  execute: (...args: ClientEvents[T]) => Promise<void> | void;
};

export const EventSchema = z.object({
  name: z.string(),
  once: z.boolean().optional().default(true),
  execute: z.function(),
});
