import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChatInputCommandInteraction,
  MessageActionRowComponentBuilder,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
} from "discord.js";
import { command } from "../../interfaces";

const build = new SlashCommandBuilder().setName("test").setDescription("test cmd");

export default command<ChatInputCommandInteraction>(
  build,
  {
    cooldown: 5000,
    developer: true,
    guildOnly: true,
    hidden: false,
  },
  async ({ interaction, logger }) => {
    logger.info("Command used by:", interaction.user.tag);

    const button = new ButtonBuilder()
      .setCustomId("test-button")
      .setLabel("Test")
      .setStyle(ButtonStyle.Primary);

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId("test-select")
      .setPlaceholder("Select an option")
      .setMinValues(1)
      .setMaxValues(5)
      .addOptions([
        { label: "Option 1", value: "option1" },
        { label: "Option 2", value: "option2" },
        { label: "Option 3", value: "option3" },
        { label: "Option 4", value: "option4" },
        { label: "Option 5", value: "option5" },
      ]);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(button);

    const row2 = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);

    await interaction.reply({
      components: [row, row2],
    });
  }
);
