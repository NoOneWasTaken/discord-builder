/*

    Context and Slash Command files for discord bot

*/

import { CommandCategory, category } from "../interfaces";
import test from "./slash/test";

export const slashCategory = [category("test", [test])] as CommandCategory[];

export const contextCategory = [] as CommandCategory[];
