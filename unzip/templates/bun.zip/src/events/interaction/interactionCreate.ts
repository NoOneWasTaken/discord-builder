import { ApplicationCommandType, ComponentType, InteractionType } from "discord.js";
import { event } from "../../interfaces";
import {
  ButtonError,
  ContextMenuError,
  ModalSubmitError,
  StringSelectError,
} from "../../embeds/errors";
import { checkInteractionOptions } from "../../utils/optionChecks";
import { handleInteractionResponse } from "../../utils/handleInteractionResponse";

export default event(
  "interactionCreate",
  { disabled: false },
  async ({ client, logger }, interaction) => {
    const interactionLogger = logger.createChild(`Interaction:${interaction.type}`);

    try {
      switch (interaction.type) {
        case InteractionType.ApplicationCommand: {
          switch (interaction.commandType) {
            case ApplicationCommandType.ChatInput: {
              const command = client.commands.get(interaction.commandName);
              if (!command) {
                throw new Error(`Slash Command ${interaction.commandName} not registered.`);
              }

              if (
                !(await checkInteractionOptions(interaction, command.options, interactionLogger))
              ) {
                return;
              }

              try {
                await command.callback({
                  client,
                  interaction,
                  logger: interactionLogger,
                  options: command.options,
                });

                await handleInteractionResponse(interaction, command.options, interactionLogger);
              } catch (err) {
                if (interaction.isRepliable()) {
                  interaction.reply({
                    embeds: [ButtonError(err as Error)],
                    ephemeral: true,
                  });
                }
                throw err;
              }
              break;
            }

            case ApplicationCommandType.User:
            case ApplicationCommandType.Message: {
              const command = client.contextMenus.get(interaction.commandName);
              if (!command) {
                throw new Error(`Context Menu Command ${interaction.commandName} not registered.`);
              }

              if (
                !(await checkInteractionOptions(interaction, command.options, interactionLogger))
              ) {
                return;
              }

              try {
                await command.callback({
                  client,
                  interaction,
                  logger: interactionLogger,
                  options: command.options,
                });

                await handleInteractionResponse(interaction, command.options, interactionLogger);
              } catch (err) {
                if (interaction.isRepliable()) {
                  interaction.reply({
                    embeds: [ButtonError(err as Error)],
                    ephemeral: true,
                  });
                }
                throw err;
              }
              break;
            }
          }
          break;
        }

        case InteractionType.MessageComponent: {
          switch (interaction.componentType) {
            case ComponentType.Button: {
              const button = client.buttons.get(interaction.customId);
              if (!button) {
                throw new Error(`Button ${interaction.customId} not registered.`);
              }

              if (
                !(await checkInteractionOptions(interaction, button.options, interactionLogger))
              ) {
                return;
              }

              try {
                await button.callback({
                  client,
                  interaction,
                  logger: interactionLogger,
                  options: button.options,
                });

                await handleInteractionResponse(interaction, button.options, interactionLogger);
              } catch (err) {
                if (interaction.isRepliable()) {
                  interaction.reply({
                    embeds: [ButtonError(err as Error)],
                    ephemeral: true,
                  });
                }
                throw err;
              }
              break;
            }

            case ComponentType.RoleSelect:
            case ComponentType.MentionableSelect:
            case ComponentType.ChannelSelect:
            case ComponentType.StringSelect: {
              const menu = client.selectMenus.get(interaction.customId);
              if (!menu) {
                throw new Error(`Select Menu ${interaction.customId} not registered.`);
              }

              if (!(await checkInteractionOptions(interaction, menu.options, interactionLogger))) {
                return;
              }

              try {
                await menu.callback({
                  client,
                  interaction,
                  logger: interactionLogger,
                  options: menu.options,
                });

                await handleInteractionResponse(interaction, menu.options, interactionLogger);
              } catch (err) {
                if (interaction.isRepliable()) {
                  interaction.reply({
                    embeds: [ButtonError(err as Error)],
                    ephemeral: true,
                  });
                }
                throw err;
              }
              break;
            }
          }
          break;
        }

        case InteractionType.ModalSubmit: {
          const modal = client.modals.get(interaction.customId);
          if (!modal) {
            throw new Error(`Modal ${interaction.customId} not registered.`);
          }

          if (!(await checkInteractionOptions(interaction, modal.options, interactionLogger))) {
            return;
          }

          try {
            await modal.callback({
              client,
              interaction,
              logger: interactionLogger,
              options: modal.options,
            });

            await handleInteractionResponse(interaction, modal.options, interactionLogger);
          } catch (err) {
            if (interaction.isRepliable()) {
              interaction.reply({
                embeds: [ButtonError(err as Error)],
                ephemeral: true,
              });
            }
            throw err;
          }
          break;
        }
      }
    } catch (err) {
      interactionLogger.error("Uncaught interaction error:", err);
    }
  }
);
