import { EmbedBuilder, Events } from "discord.js";
import { event } from "../../interfaces";

export default event(Events.ClientReady, { once: true }, async ({ client, logger }) => {
  logger.success(`${client.user?.username} has logged in!`);

  // const devChannel = client.channels.cache.get(client.config.channels.logs);
  // if (devChannel?.isTextBased()) {
  //   const embed = new EmbedBuilder()
  //     .setTitle("Logged in")
  //     .setDescription(`${client.user?.username} logged in at ${new Date().toLocaleString()}!`)
  //     .setColor(client.config.colors.primary);
  //   devChannel.send({ embeds: [embed] });
  // }
});
