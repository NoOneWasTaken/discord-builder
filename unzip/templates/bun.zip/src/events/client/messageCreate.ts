import { Events } from "discord.js";

import { event } from "../../interfaces";

export default event(Events.MessageCreate, false, async ({ client }, message) => {
  // console.log(message.content);
});
