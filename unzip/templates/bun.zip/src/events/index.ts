/*

    Event files for discord and other packages

*/

import { Event } from "../interfaces";

import clientReady from "./client/clientReady";
import messageCreate from "./client/messageCreate";

import interactionCreate from "./interaction/interactionCreate";

export default [clientReady, messageCreate, interactionCreate] as Event[];
