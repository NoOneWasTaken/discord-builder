import { appendFileSync, mkdirSync, existsSync } from "fs";
import { join } from "path";
import chalk, { ChalkInstance } from "chalk";

export class Logger {
  private static instance: Logger;
  private static logFile: string;
  private static processStartTime: Date;
  private name: string;

  private static readonly symbols = {
    INFO: "ℹ️",
    WARN: "⚠️ ",
    ERROR: "❌",
    SUCCESS: "✅",
    DEBUG: "🔍",
    TRACE: "📍",
    FATAL: "💀",
    SYSTEM: "⚙️",
    CACHE: "📦",
    DATABASE: "🗄️",
    NETWORK: "🌐",
    AUTH: "🔑",
    API: "🔌",
    EVENT: "📢",
    COMMAND: "⌨️",
  };

  private static readonly levelPadding = 8;

  private constructor(name: string = "main") {
    this.name = name;

    if (!Logger.instance) {
      Logger.processStartTime = new Date();
      const logDir = join(process.cwd(), "logs");

      try {
        if (!existsSync(logDir)) {
          mkdirSync(logDir, { recursive: true });
        }
      } catch (err) {
        console.error("Failed to create logs directory:", err);
      }

      Logger.logFile = join(logDir, `bot-${Logger.processStartTime.getTime()}.log`);
      this.initLogFile();
    }
  }

  public static getInstance(name: string = "main"): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger(name);
    }
    return Logger.instance;
  }

  private initLogFile() {
    const separator = "=".repeat(80);
    const header = [
      separator,
      `Bot Process Started at ${Logger.processStartTime.toISOString()}`,
      `Log File: ${Logger.logFile}`,
      separator,
      "",
    ].join("\n");

    appendFileSync(Logger.logFile, header);

    process.on("exit", () => this.handleProcessEnd());
    process.on("SIGINT", () => this.handleProcessEnd());
    process.on("SIGTERM", () => this.handleProcessEnd());
    process.on("uncaughtException", (err) => {
      this.error("Uncaught Exception:", err);
      this.handleProcessEnd();
    });
  }

  private handleProcessEnd() {
    const endTime = new Date();
    const runtime = (endTime.getTime() - Logger.processStartTime.getTime()) / 1000;
    const separator = "=".repeat(80);

    const footer = [
      "",
      separator,
      `Bot Process Ended at ${endTime.toISOString()}`,
      `Total Runtime: ${runtime.toFixed(2)}s`,
      separator,
      "",
    ].join("\n");

    appendFileSync(Logger.logFile, footer);
    process.exit(0);
  }

  private formatObject(obj: any): string {
    if (obj instanceof Error) {
      return `${obj.message}\n${obj.stack}`;
    }
    return typeof obj === "object" ? JSON.stringify(obj, null, 2) : String(obj);
  }

  private log(level: string, color: ChalkInstance, ...args: any[]) {
    const timestamp = new Date().toISOString();
    const symbol = Logger.symbols[level as keyof typeof Logger.symbols] || "●";
    const paddedLevel = level.padEnd(Logger.levelPadding);

    const message = args.map((arg) => this.formatObject(arg)).join(" ");

    const components = [
      symbol,
      color(paddedLevel),
      timestamp,
      "│",
      this.name.padEnd(15),
      "│",
      message,
    ];

    const consoleMessage = components.join(" ");
    console.log(consoleMessage);

    const fileMessage = `${symbol} ${paddedLevel} ${timestamp} │ ${this.name.padEnd(
      15
    )} │ ${message}\n`;
    try {
      appendFileSync(Logger.logFile, fileMessage);
    } catch (err) {
      console.error("Failed to write to log file:", err);
    }
  }

  public info(...args: any[]) {
    this.log("INFO", chalk.blue, ...args);
  }

  public warn(...args: any[]) {
    this.log("WARN", chalk.yellow, ...args);
  }

  public error(...args: any[]) {
    this.log("ERROR", chalk.red, ...args);
  }

  public debug(...args: any[]) {
    if (Bun.env.DEBUG === "true") {
      this.log("DEBUG", chalk.magenta, ...args);
    }
  }

  public success(...args: any[]) {
    this.log("SUCCESS", chalk.green, ...args);
  }

  public trace(...args: any[]) {
    this.log("TRACE", chalk.gray, ...args);
  }

  public fatal(...args: any[]) {
    this.log("FATAL", chalk.red.bold, ...args);
  }

  public system(...args: any[]) {
    this.log("SYSTEM", chalk.cyan, ...args);
  }

  createChild(name: string): Logger {
    return Logger.getInstance(`${this.name}:${name}`);
  }
}
