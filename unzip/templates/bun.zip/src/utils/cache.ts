import { createClient } from "redis";
import { Logger } from "../classes/Logger";

const logger = Logger.getInstance("Redis");

export function deleteRequireCache(includes: string) {
  for (const key in require.cache) {
    if (key.includes(includes)) {
      delete require.cache[key];
    }
  }
}

export const redis = createClient({
  url: Bun.env.REDIS_URI,
});

// Cooldown management functions
export async function getCooldown(userId: string, commandId: string): Promise<number | null> {
  const key = `cooldown:${userId}:${commandId}`;
  const remaining = await redis.get(key);
  return remaining ? parseInt(remaining) : null;
}

export async function setCooldown(
  userId: string,
  commandId: string,
  duration: number
): Promise<void> {
  const key = `cooldown:${userId}:${commandId}`;
  await redis.set(key, Date.now().toString());
  await redis.expire(key, Math.floor(duration / 1000));
}

export async function checkCooldown(
  userId: string,
  commandId: string,
  cooldownDuration: number
): Promise<{ onCooldown: boolean; remainingTime: number }> {
  const lastUsed = await getCooldown(userId, commandId);

  if (!lastUsed) {
    return { onCooldown: false, remainingTime: 0 };
  }

  const now = Date.now();
  const elapsed = now - lastUsed;
  const remaining = cooldownDuration - elapsed;

  return {
    onCooldown: remaining > 0,
    remainingTime: Math.max(0, remaining),
  };
}

// Initialize Redis connection
(async () => {
  try {
    if (Bun.env.INITIATE_REDIS === "false") {
      logger.warn("Redis initiation disabled");
      return;
    }

    if (!Bun.env.REDIS_URI) {
      logger.warn("No Redis URI provided");
      return;
    }

    await redis.connect();
    logger.success("Connected to Redis");
  } catch (err) {
    logger.error("Failed to connect to Redis:", err);
  }
})();
