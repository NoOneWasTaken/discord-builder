import {
  ActionRowBuilder,
  BaseInteraction,
  ButtonBuilder,
  ChannelSelectMenuBuilder,
  MentionableSelectMenuBuilder,
  Message,
  MessageActionRowComponentBuilder,
  RoleSelectMenuBuilder,
} from "discord.js";
import { APIButtonComponent } from "discord.js";
import { ComponentType, StringSelectMenuBuilder, UserSelectMenuBuilder } from "discord.js";
import { interactionOptions } from "../interfaces/Options";
import { Logger } from "../classes/Logger";
import { redis } from "./cache";

const localDisableTimers = new Map<string, { timestamp: number; duration: number }>();
const REDIS_KEY_PREFIX = "component:disable:";

export async function handleInteractionResponse(
  interaction: BaseInteraction,
  options: interactionOptions,
  logger: Logger
): Promise<void> {
  if (!interaction.isRepliable()) return;

  try {
    if (options.disableAfter && (interaction.isButton() || interaction.isAnySelectMenu())) {
      const message: Message = interaction.message;
      const componentId = interaction.customId;

      if (Bun.env.INITIATE_REDIS === "true") {
        await handleRedisDisable(message, componentId, options.disableAfter, logger);
      } else {
        await handleLocalDisable(message, componentId, options.disableAfter, logger);
      }
    }
  } catch (err) {
    logger.error("Error in handleInteractionResponse:", err);
    throw err;
  }
}

async function handleRedisDisable(
  message: Message,
  componentId: string,
  duration: number,
  logger: Logger
): Promise<void> {
  try {
    const key = `${REDIS_KEY_PREFIX}${componentId}`;
    const existingTimer = await redis.get(key);

    if (existingTimer) {
      const expiryTime = parseInt(existingTimer);
      if (Date.now() < expiryTime) {
        return;
      }
    }

    await redis.set(key, (Date.now() + duration).toString(), {
      EX: Math.ceil(duration / 1000),
    });

    setTimeout(async () => {
      try {
        await updateMessageComponents(message, componentId, logger);
        await redis.del(key);
      } catch (err) {
        logger.error("Failed to disable component:", err);
      }
    }, duration);
  } catch (err) {
    logger.error("Redis error in handleRedisDisable:", err);
    await handleLocalDisable(message, componentId, duration, logger);
  }
}

async function handleLocalDisable(
  message: Message,
  componentId: string,
  duration: number,
  logger: Logger
): Promise<void> {
  const now = Date.now();
  const existingTimer = localDisableTimers.get(componentId);

  if (existingTimer && now < existingTimer.timestamp + existingTimer.duration) {
    return;
  }

  localDisableTimers.set(componentId, {
    timestamp: now,
    duration: duration,
  });

  setTimeout(async () => {
    try {
      await updateMessageComponents(message, componentId, logger);
      localDisableTimers.delete(componentId);
    } catch (err) {
      logger.error("Failed to disable component:", err);
    }
  }, duration);
}

async function updateMessageComponents(
  message: Message,
  componentId: string,
  logger: Logger
): Promise<void> {
  const newComponents = message.components.map((row) => {
    const actionRow = new ActionRowBuilder<MessageActionRowComponentBuilder>();
    const newComponents = row.components.map((component) => {
      const builder = createComponentBuilder(component, logger);
      if (component.customId === componentId) {
        builder.setDisabled(true);
      }
      return builder;
    });
    return actionRow.addComponents(newComponents);
  });

  await message.edit({ components: newComponents });
  logger.debug(`Disabled component ${componentId}`);
}

function createComponentBuilder(component: any, logger: Logger): MessageActionRowComponentBuilder {
  switch (component.type) {
    case ComponentType.Button:
      return ButtonBuilder.from(component as APIButtonComponent);
    case ComponentType.StringSelect:
      return StringSelectMenuBuilder.from(component);
    case ComponentType.UserSelect:
      return UserSelectMenuBuilder.from(component);
    case ComponentType.RoleSelect:
      return RoleSelectMenuBuilder.from(component);
    case ComponentType.MentionableSelect:
      return MentionableSelectMenuBuilder.from(component);
    case ComponentType.ChannelSelect:
      return ChannelSelectMenuBuilder.from(component);
    default:
      logger.warn(`Unknown component type: ${component.type}`);
      return component;
  }
}
