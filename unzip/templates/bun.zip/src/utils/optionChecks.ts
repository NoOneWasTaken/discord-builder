import { BaseInteraction } from "discord.js";
import { Logger } from "../classes/Logger";
import { baseOptions, interactionOptions } from "../interfaces/Options";
import { checkCooldown, setCooldown } from "./cache";
import { config } from "./config";

const localCooldowns = new Map<string, { timestamp: number; duration: number }>();

export async function checkInteractionOptions(
  interaction: BaseInteraction,
  options: baseOptions | interactionOptions,
  logger: Logger
): Promise<boolean> {
  if (!interaction.isRepliable()) return true;

  const interactionType = interaction.isCommand()
    ? "command"
    : interaction.isButton()
    ? "button"
    : interaction.isAnySelectMenu()
    ? "select menu"
    : interaction.isModalSubmit()
    ? "modal"
    : "interaction";

  // Developer check
  if ("developer" in options && options.developer) {
    if (interaction.user.id !== config.info.developerId) {
      await interaction.reply({
        content: `This ${interactionType} is only available to developers!`,
        ephemeral: true,
      });
      logger.warn(`Developer-only ${interactionType} attempted by ${interaction.user.tag}`);
      return false;
    }
  }

  // Guild-only check
  if ("guildOnly" in options && options.guildOnly) {
    if (!interaction.guild) {
      await interaction.reply({
        content: `This ${interactionType} can only be used in a server!`,
        ephemeral: true,
      });
      logger.warn(`Guild-only ${interactionType} attempted in DMs by ${interaction.user.tag}`);
      return false;
    }
  }

  // Permission check
  if (options.requirePermissions && interaction.memberPermissions) {
    const missing = interaction.memberPermissions.missing(options.requirePermissions);
    if (missing.length) {
      await interaction.reply({
        content: `You're missing the following permissions: ${missing.join(", ")}`,
        ephemeral: true,
      });
      logger.warn(`Permission check failed for ${interaction.user.tag}: ${missing.join(", ")}`);
      return false;
    }
  }

  // Cooldown check
  if (options.cooldown) {
    const commandId = interaction.isCommand() ? interaction.commandName : interaction.customId;

    if (Bun.env.INITIATE_REDIS === "true") {
      const { onCooldown, remainingTime } = await checkCooldown(
        interaction.user.id,
        commandId,
        options.cooldown
      );

      if (onCooldown) {
        await interaction.reply({
          content: `Please wait ${(remainingTime / 1000).toFixed(
            1
          )} seconds before using this again.`,
          ephemeral: true,
        });
        logger.debug(`Cooldown active for ${interaction.user.tag}`);
        return false;
      }

      await setCooldown(interaction.user.id, commandId, options.cooldown);
    } else {
      const key = `${interaction.user.id}:${commandId}`;
      const now = Date.now();
      const cooldownData = localCooldowns.get(key);

      if (cooldownData) {
        const remainingTime = cooldownData.duration - (now - cooldownData.timestamp);
        if (remainingTime > 0) {
          await interaction.reply({
            content: `Please wait ${(remainingTime / 1000).toFixed(
              1
            )} seconds before using this again.`,
            ephemeral: true,
          });
          logger.debug(`Local cooldown active for ${interaction.user.tag}`);
          return false;
        }
        localCooldowns.delete(key);
      }

      localCooldowns.set(key, {
        timestamp: now,
        duration: options.cooldown,
      });

      setTimeout(() => localCooldowns.delete(key), options.cooldown);
    }
  }

  return true;
}
