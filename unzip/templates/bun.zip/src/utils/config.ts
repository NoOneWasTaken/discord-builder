import { Config } from "../interfaces";

export const config = {
  info: {
    developerId: "1045011641940574208",
    developerGuild: "690342051778396403",
    developerChannel: "1085873944751521792",
    restVersion: "10",
  },

  constraints: {
    cache_expiry: 60,
    paginationFieldLimit: 6,
    defaultPaginationTime: 60_000, // Seconds
    collectionTime: 60_000, // Seconds
  },

  colors: {
    primary: "#a565ff",
    error: "#c12a22",
    cooldown: "#ff0000",
  },
} satisfies Config;
