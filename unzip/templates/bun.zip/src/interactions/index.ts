/*

    Button, menu and modal interaction files for discord bot

*/

import { interactionCategory } from "../interfaces";

// Buttons
import testButton from "./buttons/testButton";

// Menus
import testMenu from "./menus/testmenu";

// Modals
import testModal from "./modals/testmodal";

// Exporting the categories
export const buttonCategory = [
  interactionCategory("testbutton", [testButton]),
] as interactionCategory[];

export const menuCategory = [interactionCategory("testmenu", [testMenu])] as interactionCategory[];

export const modalCategory = [
  interactionCategory("testmodal", [testModal]),
] as interactionCategory[];
