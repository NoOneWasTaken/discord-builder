import { StringSelectMenuInteraction, PermissionFlagsBits } from "discord.js";
import { selectMenu } from "../../interfaces";

export default selectMenu<StringSelectMenuInteraction>(
  "test-select",
  {
    // Time in ms after which menu will be disabled
    disableAfter: 2500,

    // Required permissions for user to use menu
    requirePermissions: [PermissionFlagsBits.ManageMessages],

    // Only allow menu in guilds
    guildOnly: true,

    // Only allow menu usage by developer (set in utils/config.ts)
    developer: true,

    // Cooldown between uses in ms
    cooldown: 5000,
  },
  async ({ interaction, logger }) => {
    const selected = interaction.values.join(", ");
    logger.info(`Menu option selected by ${interaction.user.tag}:`, selected);

    await interaction.reply({
      content: `You selected: ${selected}`,
      ephemeral: true,
    });
  }
);
