import { ModalSubmitInteraction, PermissionFlagsBits, PermissionResolvable } from "discord.js";
import { modal } from "../../interfaces";

export default modal<ModalSubmitInteraction>(
  "testmodal",
  {
    // Time in ms after which modal will be disabled
    disableAfter: 2500,

    // Required permissions for user to use modal
    requirePermissions: [PermissionFlagsBits.ManageMessages],

    // Only allow modal in guilds
    guildOnly: true,

    // Only allow modal usage by developer (set in utils/config.ts)
    developer: true,

    // Cooldown between uses in ms
    cooldown: 5000,
  },
  async ({ client, interaction, logger, options }) => {}
);
