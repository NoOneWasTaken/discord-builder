import { ButtonInteraction, PermissionFlagsBits } from "discord.js";
import { button } from "../../interfaces";

export default button<ButtonInteraction>(
  "test-button",
  {
    // Time in ms after which button will be disabled
    disableAfter: 2500,

    // Required permissions for user to use button
    requirePermissions: [PermissionFlagsBits.ManageMessages],

    // Only allow button in guilds
    guildOnly: true,

    // Only allow button usage by developer (set in utils/config.ts)
    developer: true,

    // Cooldown between uses in ms
    cooldown: 5000,
  },
  async ({ interaction, logger }) => {
    logger.info("Button clicked by:", interaction.user.tag);
    await interaction.reply("Button clicked by " + interaction.user.tag + "!");
  }
);
