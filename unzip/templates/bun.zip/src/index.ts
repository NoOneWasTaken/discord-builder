import { DiscordjsError, GatewayIntentBits, Partials } from "discord.js";
import ApplicationClient from "./classes/ApplicationClient";
import { ConnectOptions, connect } from "mongoose";
import { Logger } from "./classes/Logger";
const logger = Logger.getInstance("Process");

const client = new ApplicationClient({
  intents: [
    // Server-related Intents
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildScheduledEvents,

    // Message-related Intents
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.DirectMessageReactions,
    GatewayIntentBits.DirectMessageTyping,
    GatewayIntentBits.MessageContent,

    // Auto Moderation Configuration
    GatewayIntentBits.AutoModerationConfiguration,
    GatewayIntentBits.AutoModerationExecution,
  ],
  partials: [
    // Channel-related Partials
    Partials.Channel,
    Partials.Message,
    Partials.Reaction,

    // User-related Partials
    Partials.User,
    Partials.GuildMember,
    Partials.ThreadMember,

    // Event Partials
    Partials.GuildScheduledEvent,
  ],
  // Additional recommended client options
  failIfNotExists: false, // Don't throw if entity doesn't exist
  waitGuildTimeout: 15000, // Time to wait for guilds to be cached
  sweepers: {
    // Clean up cached messages after 12 hours
    messages: {
      interval: 43200, // 12 hours in seconds
      lifetime: 43200, // 12 hours in seconds
    },
  },
});

// Process-wide error handling
process.on("unhandledRejection", (reason, promise) => {
  logger.error("Unhandled Rejection at:", promise, "reason:", reason);
});

process.on("uncaughtException", (error) => {
  logger.error("Uncaught Exception:", error);
  process.exit(1);
});

process.on("SIGTERM", () => {
  logger.warn("SIGTERM received. Shutting down gracefully...");
  process.exit(0);
});

// Handle deployment command
if (Bun.argv.includes("--deploy")) {
  await client.deploy(true);
  process.exit(0);
}

// Client login and database connection
client
  .login(Bun.env.DISCORD_BOT_TOKEN)
  .then(async () => {
    // Check if Mongoose should be initiated
    if (Bun.env.INITIATE_MONGOOSE == "false") {
      client.logger.warn("Mongoose initiation disabled");
      return;
    }

    // Validate MongoDB URI
    if (!Bun.env.MONGOOSE_URI) {
      client.logger.warn("No database URL provided");
      return;
    }

    // Connect to MongoDB
    await connect(Bun.env.MONGOOSE_URI, {
      autoIndex: true,
    } as ConnectOptions)
      .then(() => {
        client.logger.success("Connected to the database");
      })
      .catch((err) => {
        throw new Error(`Database connection error: ${err}`);
      });
  })
  .catch((err: unknown) => {
    if (err instanceof DiscordjsError) {
      client.logger.error(`[${err.code}] ${err.name} - ${err.message}`);
      return;
    }
    throw err;
  });
