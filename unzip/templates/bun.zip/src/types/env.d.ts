declare global {
  namespace NodeJS {
    interface ProcessEnv {
      DISCORD_BOT_TOKEN: string;
      DISCORD_APP_ID: string;
      INITIATE_MONGOOSE: "true" | "false";
      MONGOOSE_URI?: string;
      INITIATE_REDIS: "true" | "false";
      REDIS_URI?: string;
      NODE_ENV?: "development" | "production";
      DEBUG: "true" | "false";
    }
  }
}
