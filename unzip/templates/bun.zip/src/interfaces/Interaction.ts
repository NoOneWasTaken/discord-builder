import ApplicationClient from "../classes/ApplicationClient";
import {
  AnySelectMenuInteraction,
  ButtonInteraction,
  Awaitable,
  Interaction as DiscordInteraction,
  ModalSubmitInteraction,
  PermissionResolvable,
} from "discord.js";
import { Logger } from "../classes/Logger";
import { buttonOptions, modalOptions, selectMenuOptions } from "./Options";

export interface interactionOptions {
  timeout?: number;
  deleteAfter?: number;
  requirePermissions?: PermissionResolvable[];
  cooldown?: number;
}

export interface interactionProps<T, O> {
  interaction: T;
  client: ApplicationClient;
  logger: Logger;
  options: O;
}

export type interactionCallback<T, O> = (props: interactionProps<T, O>) => Awaitable<unknown>;

export interface interaction<T extends DiscordInteraction, O> {
  name: string;
  options: O;
  callback: interactionCallback<T, O>;
}

export function button<T extends ButtonInteraction>(
  name: string,
  options: buttonOptions = {},
  callback: interactionCallback<T, buttonOptions>
): interaction<T, buttonOptions> {
  return { name, options, callback };
}

export function selectMenu<T extends AnySelectMenuInteraction>(
  name: string,
  options: selectMenuOptions = {},
  callback: interactionCallback<T, selectMenuOptions>
): interaction<T, selectMenuOptions> {
  return { name, options, callback };
}

export function modal<T extends ModalSubmitInteraction>(
  name: string,
  options: modalOptions = {},
  callback: interactionCallback<T, modalOptions>
): interaction<T, modalOptions> {
  return { name, options, callback };
}

export function interaction<T extends DiscordInteraction>(
  name: string,
  options: interactionOptions = {},
  callback: interactionCallback<T, interactionOptions>
): interaction<T, interactionOptions> {
  return {
    name,
    options,
    callback,
  };
}

export interface interactionCategory {
  name: string;
  interactions: interaction<DiscordInteraction, interactionOptions>[];
}

export function interactionCategory(
  name: string,
  interactions: interaction<any, any>[]
): interactionCategory {
  return {
    name,
    interactions,
  };
}
