import { PermissionResolvable } from "discord.js";

// Base options that all interactions share
export interface baseOptions {
  requirePermissions?: PermissionResolvable[];
  cooldown?: number;
  developer?: boolean;
  guildOnly?: boolean;
}

// Command specific options
export interface commandOptions {
  requirePermissions?: PermissionResolvable[];
  cooldown?: number;
  developer?: boolean;
  guildOnly?: boolean;
  hidden?: boolean;
}

// Event specific options
export interface eventOptions {
  once?: boolean;
  disabled?: boolean;
}

// Base interaction options
export interface interactionOptions extends baseOptions {
  disableAfter?: number;
}

// Component specific options
export interface buttonOptions extends interactionOptions {}

export interface selectMenuOptions extends interactionOptions {}

export interface modalOptions extends interactionOptions {}
