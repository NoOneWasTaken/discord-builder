import { ColorResolvable, Snowflake } from "discord.js";

export interface Config {
  info: {
    developerId?: Snowflake;
    developerGuild?: Snowflake;
    developerChannel?: Snowflake;
    restVersion: string;
  };

  constraints: {
    cache_expiry: number;
    paginationFieldLimit: number;
    defaultPaginationTime: number;
    collectionTime: number;
  };

  colors: {
    primary: ColorResolvable;
    error: ColorResolvable;
    cooldown: ColorResolvable;
  };
}
