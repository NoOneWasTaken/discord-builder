import ApplicationClient from "../classes/ApplicationClient";
import { ClientEvents, Awaitable } from "discord.js";
import { Logger } from "./Logger";
import { eventOptions } from "./Options";

export type eventKeys = keyof ClientEvents;

export interface eventProps {
  client: ApplicationClient;
  logger: Logger;
  options: eventOptions;
}

export type eventCallback<T extends eventKeys> = (
  props: eventProps,
  ...args: ClientEvents[T]
) => Awaitable<unknown>;

export interface event<T extends eventKeys = eventKeys> {
  key: T;
  options: eventOptions;
  callback: eventCallback<T>;
}

export function event<T extends eventKeys>(
  key: T,
  options: eventOptions = { once: false, disabled: false },
  callback: eventCallback<T>
): event<T> {
  return { key, options, callback };
}
