import ApplicationClient from "../classes/ApplicationClient";
import {
  Awaitable,
  CommandInteraction,
  ContextMenuCommandBuilder,
  SlashCommandBuilder,
  SlashCommandOptionsOnlyBuilder,
  SlashCommandSubcommandsOnlyBuilder,
} from "discord.js";
import { Logger } from "./Logger";
import { commandOptions } from "./Options";

export type commandBuild =
  | SlashCommandBuilder
  | SlashCommandSubcommandsOnlyBuilder
  | SlashCommandOptionsOnlyBuilder
  | Omit<SlashCommandBuilder, "addSubcommand" | "addSubcommandGroup">
  | ContextMenuCommandBuilder;

export interface commandProps<T> {
  interaction: T;
  client: ApplicationClient;
  logger: Logger;
  options: commandOptions;
}

export type commandCallback<T> = (props: commandProps<T>) => Awaitable<unknown>;

export interface command<T extends CommandInteraction> {
  build: commandBuild;
  callback: commandCallback<T>;
  options: commandOptions;
}

export interface commandCategory {
  name: string;
  commands: command<CommandInteraction>[];
}

export function command<T extends CommandInteraction>(
  build: commandBuild,
  options: commandOptions = {},
  callback: commandCallback<T>
): command<T> {
  return {
    build,
    options,
    callback,
  };
}

export function category(name: string, commands: command<any>[]): commandCategory {
  return {
    name,
    commands,
  };
}
