// write discord embeds exportable for errors like interaction or cmd error or modal error discord v14

import { EmbedBuilder } from "discord.js";
import { config } from "../utils";

export function InteractionError(error: Error) {
  return new EmbedBuilder()
    .setTitle(`${error.name}: ${error.message}`)
    .setColor(config.colors.error);
  // .setDescription(`\`\`\`${error.stack}\`\`\``);
}

export function ContextMenuError(error: Error) {
  return new EmbedBuilder()
    .setTitle(`${error.name}: ${error.message}`)
    .setColor(config.colors.error);
  // .setDescription(`\`\`\`${error.stack}\`\`\``);
}

export function ModalSubmitError(error: Error) {
  return new EmbedBuilder()
    .setTitle(`${error.name}: ${error.message}`)
    .setColor(config.colors.error);
  // .setDescription(`\`\`\`${error.stack}\`\`\``);
}

export function ButtonError(error: Error) {
  return new EmbedBuilder()
    .setTitle(`${error.name}: ${error.message}`)
    .setColor(config.colors.error);
  // .setDescription(`\`\`\`${error.stack}\`\`\``);
}

export function StringSelectError(error: Error) {
  return new EmbedBuilder()
    .setTitle(`${error.name}: ${error.message}`)
    .setColor(config.colors.error);
  // .setDescription(`\`\`\`${error.stack}\`\`\``);
}
